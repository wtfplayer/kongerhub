How to install:
Run the Installer.bat to install the Dark Textures.

Troubleshooting:
If you don't see your Dark Textures press esc and put your graphic settings at 3.

Credits:
Installer made by @folixx on discord.